#include "types.h"
#include "user.h"
#include "stat.h"

int main(void) 
{
    
    int result1 = nice(10);
    printf(1, "Result: %d\n", result1);

    int result2 = nice(39);
    printf(1, "Result: %d\n", result2);

    int result3 = nice(40);
    printf(1, "Result: %d\n", result3);

    int result4 = nice(-10);
    printf(1, "Result: %d\n", result4);

    int result5 = nice(0);
    printf(1, "Result: %d\n", result5);

    int result6 = nice(2147483647);
    printf(1, "Result: %d\n", result6);

    exit();
}
