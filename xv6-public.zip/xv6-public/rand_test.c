#include "types.h"
#include "user.h"
#include "stat.h"

int main(void) {
    int i;
    for (i = 0; i < 1000; i++) {
        unsigned long rand_val = xorshift();  // Assuming xorshift() is your PRNG function in the xv6 kernel
        // Adjust the range to [0, 1000]
        unsigned long scaled_rand_val = rand_val % 1001;
        printf(1, "%d\n", scaled_rand_val);
    }
    exit();
}



