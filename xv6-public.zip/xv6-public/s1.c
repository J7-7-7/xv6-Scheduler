#include "types.h"
#include "user.h"
#include "stat.h"

int is_palindrome(int n) {
    int reversed = 0;
    int original = n;
    while (n != 0) {
        reversed = reversed * 10 + n % 10;
        n /= 10;
    }
    return original == reversed;
}

void child_task(int priority) {
    printf(1, "Child with priority %d started.\n", priority);
    int palindrome = 123454321;
    if (is_palindrome(palindrome)) {
        printf(1, "123454321 is a palindrome\n");
    } 
    printf(1, "Child with priority %d finished.\n", priority);
    exit();
}

int main(void) {
    int n = 5;  
    int pid;
    int priorities[] = {0, 10, 20, 30, 39};  

    // Switch to lottery scheduling mode
    schedmod(1);
    int i;

    for (i = 0; i < n; i++) {
        pid = fork();
        if (pid < 0) {  // fork failed
            printf(1, "Fork failed\n");
            exit();
        }
        
        if (pid == 0) {  // Child process
            nice(priorities[i]);
            child_task(priorities[i]);
        }
    }

    for (i = 0; i < n; i++) {
        wait();
    }

    
    exit();
}