#include "types.h"
#include "user.h"

int calculate_sum(int base, int iter) {
    return base + iter + (iter % 3); 
}

void child_work(int child_num, int priority) {
    printf(1, "Priority set by Child %d: [%d]\n", child_num, nice(priority));
    printf(1, "Tickets for Child %d: %d\n", child_num, rettickets());
    printf(1, "I am Child: %d\n", child_num);

    int result = 0;
    int i;
    for (i = 0; i < 100; i++) {
        result = calculate_sum(result, i);
        printf(1, "Child %d: result: %d\n", child_num, result);
    }
    printf(1, "Child %d done!\n", child_num);
}

int main(void) {
    int current_mode = schedmod(1); // Setting to the new scheduling mode.
    printf(1, "Mode: %d\n", current_mode);

    if (fork() != 0) { // Parent process.
        if (fork() != 0) { // Parent process.
            wait();
        } else { // Child 2.
            child_work(2, 0); // highest priority.
        }
        wait(); 
    } else { // Child 1.
        child_work(1, 40); // lowest priority.
    }

    exit();
}
