#include "types.h"
#include "user.h"

void compute_task(int child_num) {
    int i;
    for (i = 0; i < 100; i++) {
        printf(1, "Child %d at iteration %d\n", child_num, i);

        // Priority switch at the 50th iteration.
        if (i == 49) {
            if (child_num == 1) {
                printf(1, "Child 1 changing to highest priority\n");
                nice(0);  // Change to highest priority
            } else {
                printf(1, "Child 2 changing to lowest priority\n");
                nice(40);  // Change to lowest priority
            }
        }

        
        int tmp = 0;
        int j;
        for (j = 0; j < 10000; j++) {
            tmp += j;
        }
    }
    printf(1, "Child %d has finished!\n", child_num);  
}

int main(void) {
    // Switch to lottery scheduling mode
    schedmod(1);

    // Create Child 1
    int pid1 = fork();
    if (pid1 == 0) {  // Child 1
        printf(1, "Child 1 setting to lowest priority\n");
        nice(40);  // Set to lowest priority
        compute_task(1);
        exit();
    }

    // Create Child 2
    int pid2 = fork();
    if (pid2 == 0) {  // Child 2
        printf(1, "Child 2 setting to highest priority\n");
        nice(0);  // Set to highest priority
        compute_task(2);
        exit();
    }

    
    wait();
    wait();

    exit();
}
