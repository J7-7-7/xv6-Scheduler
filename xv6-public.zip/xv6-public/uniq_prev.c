#include "types.h"
#include "stat.h"
#include "user.h"

char* fgets(char* buf, int n, int file) 
{
    int i;
    char c;
    for (i = 0; i < n - 1; i++) 
    {
        if (read(file, &c, 1) != 1)
            break;
        buf[i] = c;
        if (c == '\n')
            break;
    }
    buf[i] = '\0';
    return i > 0 ? buf : 0;
}

int compare_string(const char *str_1, const char *str_2) 
{
    while (*str_1 && *str_2) 
    {
        char c1 = *str_1;
        char c2 = *str_2;
        if ('A' <= c1 && c1 <= 'Z') 
        {
            c1 += 'a' - 'A';
        }
        if ('A' <= c2 && c2 <= 'Z') 
        {
            c2 += 'a' - 'A';
        }
        if (c1 != c2) 
        {
            return c1 - c2;
        }
        str_1++;
        str_2++;
    }
    return (*str_1) - (*str_2);
}

void uniq(int fd, int count_option, int case_insen) 
{
    char current_line[1024];
    char next_line[1024];
    int count = 1;

    if (fgets(current_line, sizeof(current_line), fd) == 0)
        return;
        
    while (fgets(next_line, sizeof(next_line), fd) != 0) 
    {
        int comp_res = case_insen ? compare_string(current_line, next_line) : strcmp(current_line, next_line);
        if (comp_res == 0) 
        {
            count++;
        } 
        else 
        {
            if (count_option) 
            {
                printf(1, "%d %s\n", count, current_line); 
            } 
            else 
            {
                printf(1, "%s\n", current_line); 
            }
            count = 1;
            strcpy(current_line, next_line);
        }
    }
    if (count_option) 
    {
        printf(1, "%d %s\n", count, current_line); 
    } 
    else 
    {
        printf(1, "%s\n", current_line); 
    }
}

void uniq_d(int fd, int case_insen) 
{
    char current_line[1024];
    char next_line[1024];
    int duplicate = 0;
    if (fgets(current_line, sizeof(current_line), fd) == 0)
        return;
    while (fgets(next_line, sizeof(next_line), fd) != 0) 
    {
        int comp_res = case_insen ? compare_string(current_line, next_line) : strcmp(current_line, next_line);
        if (comp_res == 0) 
        {
            duplicate = 1;
        } else if (duplicate) 
        {
            printf(1, "%s\n", current_line); 
            duplicate = 0; 
        }
        strcpy(current_line, next_line);
    }
    if (duplicate) 
    {
        printf(1, "%s\n", current_line); 
    }
}


int main(int argc, char *argv[]) 
{
    int fd;
    int count = 0;
    int case_insen = 0;

    int i,j;
    for (i = 1; i < argc; i++) 
    {
        if (strcmp(argv[i], "-i") == 0) 
        {
            case_insen = 1;
            for (j = i; j < argc - 1; j++) 
            {
                argv[j] = argv[j + 1];
            }
            argc--;
            i--;
        } 
        else if (strcmp(argv[i], "-c") == 0) 
        {
            count = 1;
            int j;
            for (j = i; j < argc - 1; j++) 
            {
                argv[j] = argv[j + 1];
            }
            argc--;
            i--;
        }
    }

    if (argc > 1 && strcmp(argv[1], "|") == 0) 
    {
        uniq(0, count, case_insen);
    }
    
    else if (argc > 1 && strcmp(argv[1], "-d") == 0) 
    {
        argc--; 
        argv++; 
        if (argc == 1) 
        {
            uniq_d(0, case_insen);
        } 
        else 
        {
            if ((fd = open(argv[1], 0)) < 0) 
            {
                exit();
            }
            uniq_d(fd, case_insen);
            close(fd);
        }
    }
    else if (argc <= 1) 
    {
        uniq(0, count, case_insen); 
    }
    else 
    {
        if ((fd = open(argv[1], 0)) < 0) 
        {
            exit();
        }
        uniq(fd, count, case_insen);
        close(fd);
    }

    exit();
}